﻿#ifndef DEMO_SERIAL_PORT_H
#define DEMO_SERIAL_PORT_H

#include <QByteArray>
#include <QSerialPort>
#include <QString>
#include <QStringList>

class MotorSerialPort
{
public:
    struct Result
    {
        bool success = false;
        QString message;
    };

    struct MotorSnapshot
    {
        qint32 position = 0;
        quint8 runState = 0;
        bool enabled = false;
        bool inPosition = false;
    };

    QStringList availablePorts() const;
    bool open(const QString& portName, qint32 baudRate, QString& errorMessage);
    void close();
    bool isOpen() const;

    void setDeviceAddress(quint8 address);
    quint8 deviceAddress() const;

    Result setCommunicationPositionMode();
    Result clearState();
    Result enableMotor(bool enable);
    Result stopMotor();
    Result moveRelative(bool forward, quint16 speedRpm, quint8 acceleration, quint32 position);

    Result readPosition(qint32& position);
    Result readRunState(quint8& runState);
    Result readEnableState(bool& enabled);
    Result readInPosition(bool& inPosition);
    Result readSnapshot(MotorSnapshot& snapshot);

    static QString runStateText(quint8 runState);

private:
    Result transact(quint8 commandCode, const QByteArray& requestData, int expectedDataBytes, QByteArray& responseData);
    QByteArray buildFrame(quint8 commandCode, const QByteArray& requestData) const;
    quint8 calculateChecksum(const QByteArray& bytes) const;
    void clearInputBuffer();

    static QString errorCodeText(quint8 errorCode);
    static quint16 readUInt16(const QByteArray& data, int offset);
    static qint32 readInt32(const QByteArray& data, int offset);

    QSerialPort serial_;
    quint8 deviceAddress_ = 0x01;
    int timeoutMs_ = 300;
};

#endif

