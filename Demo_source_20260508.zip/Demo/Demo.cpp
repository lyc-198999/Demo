﻿#include "Demo.h"
#include "ui_Demo.h"

#include <QDateTime>
#include <QPixmap>
#include <QStringList>
#include <QTextDocument>

// 由 ImOpenCV.cpp 提供图像采集函数
cv::Mat GetFrameFromCamera();

namespace
{
constexpr int kFrameIntervalMs = 30;
constexpr int kMaxLogBlocks = 200;
constexpr double kPulsesPerTurn = 51200.0;

QImage matToQImage(const cv::Mat& mat)
{
    if (mat.empty())
    {
        return {};
    }

    switch (mat.type())
    {
    case CV_8UC1:
        return QImage(mat.data,
                      mat.cols,
                      mat.rows,
                      static_cast<qsizetype>(mat.step),
                      QImage::Format_Grayscale8).copy();

    case CV_8UC3:
    {
        cv::Mat rgb;
        cv::cvtColor(mat, rgb, cv::COLOR_BGR2RGB);
        return QImage(rgb.data,
                      rgb.cols,
                      rgb.rows,
                      static_cast<qsizetype>(rgb.step),
                      QImage::Format_RGB888).copy();
    }

    case CV_8UC4:
    {
        cv::Mat rgba;
        cv::cvtColor(mat, rgba, cv::COLOR_BGRA2RGBA);
        return QImage(rgba.data,
                      rgba.cols,
                      rgba.rows,
                      static_cast<qsizetype>(rgba.step),
                      QImage::Format_RGBA8888).copy();
    }

    default:
        return {};
    }
}
}

MainWindow::MainWindow(QWidget* parent)
    : QMainWindow(parent)
    , ui(new Ui::DemoClass)
    , timer(new QTimer(this))
{
    ui->setupUi(this);

    ui->combo_baud->addItems(QStringList{ "9600", "19200", "38400", "57600", "115200" });
    ui->combo_baud->setCurrentText("115200");
    ui->text_log->document()->setMaximumBlockCount(kMaxLogBlocks);
    ui->btn_connect->setCheckable(true);
    ui->btn_emergency_stop->setCheckable(true);

    connect(timer, &QTimer::timeout, this, &MainWindow::updateFrame);
    connect(ui->radio_auto, &QRadioButton::toggled, this, &MainWindow::updateManualControlState);
    connect(ui->radio_manual, &QRadioButton::toggled, this, &MainWindow::updateManualControlState);
    connect(ui->btn_refresh, &QPushButton::clicked, this, &MainWindow::refreshSerialControls);
    connect(ui->btn_connect, &QPushButton::clicked, this, &MainWindow::toggleSerialConnection);
    connect(ui->btn_forward, &QPushButton::clicked, this, &MainWindow::handleManualForward);
    connect(ui->btn_backward, &QPushButton::clicked, this, &MainWindow::handleManualBackward);
    connect(ui->btn_emergency_stop, &QPushButton::toggled, this, &MainWindow::toggleEmergencyStop);

    refreshSerialControls();
    updateManualControlState();
    updateStatusDisplay();
    appendLog("窗口初始化完成。");
    appendLog("串口控制已切换为正点原子自定义协议模式。");
    appendLog(QString("手动模式默认参数：步数=%1，速度=%2RPM，加减速度=%3。")
                  .arg(manualStep)
                  .arg(manualSpeedRpm)
                  .arg(manualAcceleration));

    timer->start(kFrameIntervalMs);
}

MainWindow::~MainWindow()
{
    if (motorSerial.isOpen())
    {
        motorSerial.close();
    }

    delete ui;
}

void MainWindow::resizeEvent(QResizeEvent* event)
{
    QMainWindow::resizeEvent(event);
    refreshDisplayedImage();
}

void MainWindow::updateFrame()
{
    frame = GetFrameFromCamera();
    if (frame.empty())
    {
        if (cameraOnline)
        {
            appendLog("相机图像流中断。");
        }

        cameraOnline = false;
        frameFormatValid = false;
        currentSharpness = 0.0;
        currentImage = QImage();

        ui->label_image->setPixmap(QPixmap());
        ui->label_image->setText("无图像");
        updateStatusDisplay();
        return;
    }

    if (!cameraOnline)
    {
        appendLog("相机图像流已恢复。");
    }

    cameraOnline = true;
    showFrame(frame);
    currentSharpness = frameFormatValid ? AutoFocus::CalculateSharpness(frame) : 0.0;
    updateStatusDisplay();
}

void MainWindow::updateManualControlState()
{
    const bool isManualMode = ui->radio_manual->isChecked();
    if (manualModeSelected != isManualMode)
    {
        appendLog(isManualMode ? "已切换到手动模式。" : "已切换到自动模式。");
        manualModeSelected = isManualMode;
    }

    ui->group_manual->setEnabled(isManualMode && !emergencyStopActive);
    updateStatusDisplay();
}

void MainWindow::refreshSerialControls()
{
    const QString currentPort = ui->combo_serial->currentText();
    const QStringList ports = motorSerial.availablePorts();

    ui->combo_serial->clear();
    ui->combo_serial->addItems(ports);

    const int previousIndex = ui->combo_serial->findText(currentPort);
    if (previousIndex >= 0)
    {
        ui->combo_serial->setCurrentIndex(previousIndex);
    }
    else if (!ports.isEmpty())
    {
        ui->combo_serial->setCurrentIndex(0);
    }

    if (ports.isEmpty())
    {
        appendLog("未检测到可用串口。");
    }
    else
    {
        appendLog(QString("串口列表已刷新，检测到 %1 个串口。").arg(ports.size()));
    }
}

void MainWindow::toggleSerialConnection()
{
    if (!ui->btn_connect->isChecked())
    {
        if (motorSerial.isOpen())
        {
            motorSerial.close();
        }

        serialConnected = false;
        motorEnabled = false;
        motorInPosition = false;
        motorRunState = "未连接";
        currentPosition = 0;
        ui->btn_connect->setText("连接");
        appendLog("串口已断开。");
        updateStatusDisplay();
        return;
    }

    const QString portName = ui->combo_serial->currentText();
    const qint32 baudRate = ui->combo_baud->currentText().toInt();
    if (portName.isEmpty() || baudRate <= 0)
    {
        ui->btn_connect->setChecked(false);
        appendLog("串口连接失败：端口号或波特率无效。");
        return;
    }

    QString errorMessage;
    if (!motorSerial.open(portName, baudRate, errorMessage))
    {
        ui->btn_connect->setChecked(false);
        ui->btn_connect->setText("连接");
        serialConnected = false;
        appendLog(QString("串口打开失败：%1").arg(errorMessage));
        updateStatusDisplay();
        return;
    }

    appendLog(QString("串口已打开：%1，波特率 %2，从机地址默认使用 1。")
                  .arg(portName)
                  .arg(baudRate));

    MotorSerialPort::Result result = motorSerial.setCommunicationPositionMode();
    if (!result.success)
    {
        appendLog(QString("切换通信位置模式失败：%1").arg(result.message));
        motorSerial.close();
        ui->btn_connect->setChecked(false);
        ui->btn_connect->setText("连接");
        serialConnected = false;
        updateStatusDisplay();
        return;
    }
    appendLog("已切换到通信位置模式。");

    result = motorSerial.clearState();
    if (!result.success)
    {
        appendLog(QString("清除驱动器状态失败：%1").arg(result.message));
        motorSerial.close();
        ui->btn_connect->setChecked(false);
        ui->btn_connect->setText("连接");
        serialConnected = false;
        updateStatusDisplay();
        return;
    }
    appendLog("已清除驱动器状态。");

    result = motorSerial.enableMotor(true);
    if (!result.success)
    {
        appendLog(QString("电机使能失败：%1").arg(result.message));
        motorSerial.close();
        ui->btn_connect->setChecked(false);
        ui->btn_connect->setText("连接");
        serialConnected = false;
        updateStatusDisplay();
        return;
    }

    serialConnected = true;
    motorEnabled = true;
    ui->btn_connect->setText("断开");
    appendLog("电机已使能，可以进行手动移动。");
    synchronizeMotorStatus();
}

void MainWindow::handleManualForward()
{
    handleManualMove(static_cast<double>(manualStep));
}

void MainWindow::handleManualBackward()
{
    handleManualMove(-static_cast<double>(manualStep));
}

void MainWindow::toggleEmergencyStop(bool active)
{
    emergencyStopActive = active;
    ui->btn_emergency_stop->setText(active ? "恢复" : "急停");

    if (active)
    {
        appendLog("已触发急停。");
        if (serialConnected)
        {
            const MotorSerialPort::Result result = motorSerial.stopMotor();
            if (result.success)
            {
                appendLog("已向驱动器发送立即停止命令。");
            }
            else
            {
                appendLog(QString("发送急停命令失败：%1").arg(result.message));
            }

            synchronizeMotorStatus(false);
        }
    }
    else
    {
        appendLog("急停已解除。");
        if (serialConnected)
        {
            MotorSerialPort::Result result = motorSerial.clearState();
            if (!result.success)
            {
                appendLog(QString("解除急停后清状态失败：%1").arg(result.message));
            }
            else
            {
                appendLog("已清除刹车/失能状态。");
            }

            result = motorSerial.enableMotor(true);
            if (!result.success)
            {
                appendLog(QString("解除急停后重新使能失败：%1").arg(result.message));
            }
            else
            {
                appendLog("已重新使能电机。");
                motorEnabled = true;
            }

            synchronizeMotorStatus(false);
        }
    }

    updateManualControlState();
}

void MainWindow::showFrame(const cv::Mat& frame)
{
    currentImage = matToQImage(frame);
    frameFormatValid = !currentImage.isNull();

    if (!frameFormatValid)
    {
        ui->label_image->setPixmap(QPixmap());
        ui->label_image->setText("不支持的图像帧");
        appendLog("接收到不支持的图像帧格式。");
        updateStatusDisplay();
        return;
    }

    refreshDisplayedImage();
}

void MainWindow::refreshDisplayedImage()
{
    if (currentImage.isNull())
    {
        return;
    }

    const QSize targetSize = ui->label_image->size();
    if (!targetSize.isValid())
    {
        return;
    }

    ui->label_image->setText(QString());
    ui->label_image->setPixmap(QPixmap::fromImage(currentImage).scaled(
        targetSize,
        Qt::KeepAspectRatio,
        Qt::SmoothTransformation));
}

void MainWindow::updateStatusDisplay()
{
    ui->label_position->setText(QString("%1 脉冲（%2 圈）")
                                    .arg(currentPosition)
                                    .arg(static_cast<double>(currentPosition) / kPulsesPerTurn, 0, 'f', 3));
    ui->label_sharpness->setText(cameraOnline && frameFormatValid
                                     ? QString::number(currentSharpness, 'f', 2)
                                     : "--");

    QStringList statusParts;
    statusParts << (ui->radio_manual->isChecked() ? "手动模式" : "自动模式");

    if (emergencyStopActive)
    {
        statusParts << "已触发急停";
    }

    statusParts << (serialConnected ? "串口已连接" : "串口未连接");

    if (serialConnected)
    {
        statusParts << motorRunState;
        statusParts << (motorEnabled ? "电机已使能" : "电机未使能");
        statusParts << (motorInPosition ? "已到位" : "未到位");
    }

    if (!cameraOnline)
    {
        statusParts << "相机未连接";
    }
    else if (!frameFormatValid)
    {
        statusParts << "图像帧格式错误";
    }

    ui->label_status->setText(statusParts.join(" | "));
}

void MainWindow::synchronizeMotorStatus(bool logOnFailure)
{
    if (!serialConnected)
    {
        return;
    }

    MotorSerialPort::MotorSnapshot snapshot;
    const MotorSerialPort::Result result = motorSerial.readSnapshot(snapshot);
    if (!result.success)
    {
        if (logOnFailure)
        {
            appendLog(QString("读取电机状态失败：%1").arg(result.message));
        }
        return;
    }

    currentPosition = snapshot.position;
    motorRunState = MotorSerialPort::runStateText(snapshot.runState);
    motorEnabled = snapshot.enabled;
    motorInPosition = snapshot.inPosition;
    updateStatusDisplay();
}

void MainWindow::appendLog(const QString& message)
{
    const QString timestamp = QDateTime::currentDateTime().toString("HH:mm:ss");
    ui->text_log->appendPlainText(QString("[%1] %2").arg(timestamp).arg(message));
}

void MainWindow::handleManualMove(double delta)
{
    if (emergencyStopActive)
    {
        appendLog("当前处于急停状态，已忽略手动移动指令。");
        return;
    }

    if (!ui->radio_manual->isChecked())
    {
        appendLog("当前为自动模式，已忽略手动移动指令。");
        return;
    }

    if (!serialConnected)
    {
        appendLog("当前串口未连接，无法发送手动移动指令。");
        return;
    }

    const bool forward = delta > 0.0;
    const quint32 pulseCount = static_cast<quint32>(qAbs(delta));
    MotorSerialPort::Result result = motorSerial.moveRelative(forward,
                                                              manualSpeedRpm,
                                                              manualAcceleration,
                                                              pulseCount);
    if (!result.success)
    {
        appendLog(QString("发送手动移动指令失败：%1").arg(result.message));
        return;
    }

    motorRunState = "正在运行";
    motorInPosition = false;
    updateStatusDisplay();

    appendLog(QString("已发送手动%1指令：步数=%2，速度=%3RPM，加减速度=%4。")
                  .arg(forward ? "前进" : "后退")
                  .arg(pulseCount)
                  .arg(manualSpeedRpm)
                  .arg(manualAcceleration));

    QTimer::singleShot(150, this, [this]() { synchronizeMotorStatus(false); });
    QTimer::singleShot(600, this, [this]() { synchronizeMotorStatus(false); });
}

