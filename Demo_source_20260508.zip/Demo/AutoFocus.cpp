﻿#include "AutoFocus.h"

#include <algorithm>
#include <cmath>
#include <numeric>
#include <stdexcept>

namespace AutoFocus
{
double CalculateSharpness(const cv::Mat& image)
{
    if (image.empty())
    {
        return 0.0;
    }

    cv::Mat gray;
    if (image.channels() == 3)
    {
        cv::cvtColor(image, gray, cv::COLOR_BGR2GRAY);
    }
    else if (image.channels() == 4)
    {
        cv::cvtColor(image, gray, cv::COLOR_BGRA2GRAY);
    }
    else
    {
        gray = image;
    }

    cv::Mat laplacian;
    cv::Laplacian(gray, laplacian, CV_32F, 3);

    cv::Scalar meanValue;
    cv::Scalar stddevValue;
    cv::meanStdDev(laplacian, meanValue, stddevValue);
    return stddevValue[0] * stddevValue[0];
}

LinearRegressionResult LinearRegression(const std::vector<double>& x, const std::vector<double>& y)
{
    if (x.size() != y.size() || x.size() < 2)
    {
        throw std::invalid_argument("线性回归输入数据长度不匹配。");
    }

    const double meanX = std::accumulate(x.begin(), x.end(), 0.0) / static_cast<double>(x.size());
    const double meanY = std::accumulate(y.begin(), y.end(), 0.0) / static_cast<double>(y.size());

    double numerator = 0.0;
    double denominator = 0.0;
    for (size_t i = 0; i < x.size(); ++i)
    {
        numerator += (x[i] - meanX) * (y[i] - meanY);
        denominator += (x[i] - meanX) * (x[i] - meanX);
    }

    LinearRegressionResult result;
    if (std::abs(denominator) < 1e-12)
    {
        result.intercept = meanY;
        return result;
    }

    result.slope = numerator / denominator;
    result.intercept = meanY - result.slope * meanX;
    return result;
}

LegendreFitResult LegendreFitQuadratic(const std::vector<double>& xValues,
                                       const std::vector<double>& yValues)
{
    if (xValues.size() != yValues.size() || xValues.size() < 3)
    {
        throw std::invalid_argument("勒让德拟合输入数据长度不匹配。");
    }

    const auto [minIt, maxIt] = std::minmax_element(xValues.begin(), xValues.end());
    const double xMin = *minIt;
    const double xMax = *maxIt;
    const double diff = xMax - xMin;
    if (std::abs(diff) < 1e-12)
    {
        throw std::invalid_argument("拟合位置数据不能全部相同。");
    }

    LegendreFitResult result;
    result.alpha = 2.0 / diff;
    result.beta = -(xMax + xMin) / diff;

    cv::Mat design(static_cast<int>(xValues.size()), 3, CV_64F);
    cv::Mat yMat(static_cast<int>(yValues.size()), 1, CV_64F);

    for (int i = 0; i < static_cast<int>(xValues.size()); ++i)
    {
        const double xNorm = result.alpha * xValues[static_cast<size_t>(i)] + result.beta;
        design.at<double>(i, 0) = 1.0;
        design.at<double>(i, 1) = xNorm;
        design.at<double>(i, 2) = 0.5 * (3.0 * xNorm * xNorm - 1.0);
        yMat.at<double>(i, 0) = yValues[static_cast<size_t>(i)];
    }

    cv::Mat coeffs;
    if (!cv::solve(design, yMat, coeffs, cv::DECOMP_SVD))
    {
        throw std::runtime_error("勒让德拟合失败。");
    }

    for (int i = 0; i < 3; ++i)
    {
        result.coeffs[static_cast<size_t>(i)] = coeffs.at<double>(i, 0);
    }

    return result;
}

double DerivativeAt(const LegendreFitResult& fit, double xValue)
{
    const double xNorm = fit.alpha * xValue + fit.beta;
    return fit.alpha * (3.0 * fit.coeffs[2] * xNorm + fit.coeffs[1]);
}

std::vector<double> DerivativeSeries(const LegendreFitResult& fit, const std::vector<double>& xValues)
{
    std::vector<double> derivatives;
    derivatives.reserve(xValues.size());

    for (double xValue : xValues)
    {
        derivatives.push_back(DerivativeAt(fit, xValue));
    }

    return derivatives;
}

double FinalStepCalculate(const std::vector<double>& zValues, const std::vector<double>& sValues)
{
    if (zValues.size() != sValues.size() || zValues.size() < 3)
    {
        throw std::invalid_argument("最终步长计算输入数据长度不匹配。");
    }

    const double baseline = *std::min_element(sValues.begin(), sValues.end());
    std::vector<double> weights;
    weights.reserve(sValues.size());

    for (double value : sValues)
    {
        weights.push_back(std::max(value - baseline, 1e-9));
    }

    const double weightSum = std::accumulate(weights.begin(), weights.end(), 0.0);
    if (weightSum < 1e-12)
    {
        return 0.0;
    }

    double mu = 0.0;
    for (size_t i = 0; i < zValues.size(); ++i)
    {
        mu += zValues[i] * weights[i];
    }
    mu /= weightSum;

    return mu - zValues.back();
}

bool LastThreeDecreasing(const std::vector<double>& values)
{
    if (values.size() < 4)
    {
        return false;
    }

    const size_t n = values.size();
    return values[n - 1] < values[n - 2] &&
           values[n - 2] < values[n - 3] &&
           values[n - 3] < values[n - 4];
}

std::vector<double> Tail(const std::vector<double>& values, size_t count)
{
    if (values.size() <= count)
    {
        return values;
    }

    return std::vector<double>(values.end() - static_cast<long long>(count), values.end());
}
}

