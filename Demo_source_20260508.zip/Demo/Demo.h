﻿#ifndef DEMO_MAINWINDOW_H
#define DEMO_MAINWINDOW_H

#include "AutoFocus.h"
#include "SerialPort.h"

#include <QImage>
#include <QMainWindow>
#include <QResizeEvent>
#include <QString>
#include <QTimer>
#include <opencv2/opencv.hpp>

QT_BEGIN_NAMESPACE
namespace Ui { class DemoClass; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget* parent = nullptr);
    ~MainWindow();

private slots:
    void updateFrame();
    void updateManualControlState();
    void refreshSerialControls();
    void toggleSerialConnection();
    void handleManualForward();
    void handleManualBackward();
    void toggleEmergencyStop(bool active);

private:
    void resizeEvent(QResizeEvent* event) override;
    void showFrame(const cv::Mat& frame);
    void refreshDisplayedImage();
    void updateStatusDisplay();
    void synchronizeMotorStatus(bool logOnFailure = true);
    void appendLog(const QString& message);
    void handleManualMove(double delta);

    Ui::DemoClass* ui;
    QTimer* timer;
    MotorSerialPort motorSerial;

    cv::Mat frame;
    QImage currentImage;
    qint32 currentPosition = 0;
    double currentSharpness = 0.0;
    quint32 manualStep = 3200;
    quint16 manualSpeedRpm = 800;
    quint8 manualAcceleration = 20;
    bool cameraOnline = false;
    bool frameFormatValid = false;
    bool serialConnected = false;
    bool emergencyStopActive = false;
    bool manualModeSelected = false;
    bool motorEnabled = false;
    bool motorInPosition = false;
    QString motorRunState = "未连接";
};

#endif

