#ifndef AUTO_FOCUS_H
#define AUTO_FOCUS_H

#include <array>
#include <opencv2/opencv.hpp>
#include <vector>

namespace AutoFocus
{
inline constexpr double kDefaultStepSize = 1.0;

struct LinearRegressionResult
{
    double slope = 0.0;
    double intercept = 0.0;
};

struct LegendreFitResult
{
    std::array<double, 3> coeffs {};
    double alpha = 0.0;
    double beta = 0.0;
};

double CalculateSharpness(const cv::Mat& image);
LinearRegressionResult LinearRegression(const std::vector<double>& x, const std::vector<double>& y);
LegendreFitResult LegendreFitQuadratic(const std::vector<double>& xValues,
                                       const std::vector<double>& yValues);
double DerivativeAt(const LegendreFitResult& fit, double xValue);
std::vector<double> DerivativeSeries(const LegendreFitResult& fit, const std::vector<double>& xValues);
double FinalStepCalculate(const std::vector<double>& zValues, const std::vector<double>& sValues);
bool LastThreeDecreasing(const std::vector<double>& values);
std::vector<double> Tail(const std::vector<double>& values, size_t count);
}

#endif
